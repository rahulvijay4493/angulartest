import {Component, Inject} from '@angular/core';
import {Validators, FormBuilder, FormGroup} from '@angular/forms';
import {ValidationService} from '../services/config/config.service';
import {MdDialog, MdDialogRef} from '@angular/material';

@Component({
  selector: 'app-add-data',
  templateUrl: './add-edit-data.component.html',
  styleUrls: ['./add-edit-data.component.css'],
  providers: []
})
export class AddEditComponent {
  public addForm : FormGroup;
  heading: string = 'Add Details';
  saveBtnTitle: string = 'Add';
  mode:string = 'add';
  data: any;
  constructor(private formBuilder: FormBuilder,public dialogRef: MdDialogRef<AddEditComponent>) {
    this.addForm = this.formBuilder.group({
      name: ['',  [Validators.required,Validators.minLength(3),Validators.maxLength(50)]],
      mobileNumber: ['',  [Validators.required,Validators.maxLength(10),ValidationService.checkLimit(5000000000,9999999999)]],
      email: ['',  [Validators.required, ValidationService.emailValidator]],
      age: ['',  [Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
    });

  }

  ngOnInit(){
    if(this.mode == 'add'){

    } else {
      this.addForm.patchValue(this.data);
    }
  }

  submitData({value, valid}) {
   if (!valid) {
    this.addForm.markAsDirty({onlySelf: true});
    this.addForm.controls['name'].markAsTouched();
    this.addForm.controls['email'].markAsTouched();
    this.addForm.controls['mobileNumber'].markAsTouched();
    this.addForm.controls['age'].markAsTouched();
  }else {
     this.addForm.markAsPristine();
     this.dialogRef.close(value);
  }
  }

  cancel(){
    this.dialogRef.close();
  }
}