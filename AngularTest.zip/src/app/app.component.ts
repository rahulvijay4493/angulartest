import {Component, OnInit} from '@angular/core';
import {Todo} from './todo';
import {TodoDataService} from './todo-data.service';
import { MdDialog } from '@angular/material';
import { AddEditComponent } from './add-edit-data/add-edit-data.component';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [TodoDataService]
})
export class AppComponent implements OnInit {
  empListData: any;
  newTodo: Todo = new Todo();
  dialogOptions: any = {
        width: '510px',
        height: 'auto',
        panelClass: 'appModalPopup'
    };

  constructor(private todoDataService: TodoDataService, public dialog: MdDialog) {
  }

  ngOnInit() {
    this.empListData = [{
      "name": "Rahul Jadhav",
      "age": 28,
      "email": "rahulvijay4493@gmail.com",
      "mobileNumber": 9762632272 
     }];
  }

  addDataPopup() {
        let addData = this.dialog.open(AddEditComponent, this.dialogOptions);
        addData.componentInstance.heading = 'Add Details';
        addData.componentInstance.saveBtnTitle = 'Add';
        addData.componentInstance.mode = 'add';

        addData.afterClosed().subscribe(result => {
            if (!isNullOrUndefined(result)) {
              this.empListData.push(result);
            }
        });
    }

  addTodo() {
    this.todoDataService.addTodo(this.newTodo);
    this.newTodo = new Todo();
  }

  toggleTodoComplete(todo) {
    this.todoDataService.toggleTodoComplete(todo);
  }

  removeTodo(todo) {
    this.todoDataService.deleteTodoById(todo.id);
  }

  get todos() {
    return this.todoDataService.getAllTodos();
  }

  editEmployee(value,i){
    let addData = this.dialog.open(AddEditComponent, this.dialogOptions);
        addData.componentInstance.heading = 'Edit Details';
        addData.componentInstance.saveBtnTitle = 'Update';
        addData.componentInstance.data = value;
        addData.componentInstance.mode = 'edit';

        addData.afterClosed().subscribe(result => {
            if (!isNullOrUndefined(result)) {
              this.empListData[i]=result;
            }
        });
  }

  deleteEmployee(i){
    this.empListData.splice(i,1)
  }

}