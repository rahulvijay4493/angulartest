import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MaterialModule, MdButtonModule, MdInputModule, MdTableModule, MdIconModule } from '@angular/material';
import {AddEditComponent} from './add-edit-data/add-edit-data.component';

const routes: Routes = [     
    { 
      path: 'home', 
      component: AppComponent            
    }
];

@NgModule({
  declarations: [
    AppComponent,
    AddEditComponent
  ],
  imports: [
    RouterModule.forRoot(routes),
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    MaterialModule,
    MdInputModule,
    MdTableModule,
    MdIconModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  exports:[RouterModule],
  entryComponents: [AddEditComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
